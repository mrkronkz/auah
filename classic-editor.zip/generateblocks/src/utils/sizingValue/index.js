export default function sizingValue( value, sizing ) {
	return sizing && sizing[ value ];
}
