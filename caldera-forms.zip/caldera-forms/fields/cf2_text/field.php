<?php
printf( '<div id="%s"></div>', esc_attr( "cf2-$field_base_id") );