<#

var field = data.field,
    name = data.name,
    value = data.value;

#>
<input type="hidden" class="pp-field-hidden" name="{{name}}" value="{{value}}" />
