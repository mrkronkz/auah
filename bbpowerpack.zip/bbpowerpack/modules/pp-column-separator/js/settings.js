(function($){

	FLBuilder.registerModuleHelper('pp-column-separator', {

		rules: {
		},

	});

})(jQuery);
