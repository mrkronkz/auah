(function($) {

	$(function() {

		new PPContactForm({
			id: '<?php echo $id ?>'
		});
	});

})(jQuery);
