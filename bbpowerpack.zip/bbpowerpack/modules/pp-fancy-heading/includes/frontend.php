<<?php echo $settings->html_tag; ?> class="pp-fancy-heading-title"><?php echo $settings->heading_title; ?></<?php echo $settings->html_tag; ?>>
