/**
 * This file should contain frontend logic for 
 * all module instances.
 */