/**
 * $module An instance of your module class.
 * $id The module's ID.
 * $settings The module's settings.
*/
