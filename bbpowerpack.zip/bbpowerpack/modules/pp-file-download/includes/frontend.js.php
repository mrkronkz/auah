;( function ($) {
	new PPFileDownload( {
		id: '<?php echo $id; ?>',
	} );
} )( jQuery );