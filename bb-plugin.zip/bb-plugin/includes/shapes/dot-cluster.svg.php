<g class="fl-shape">
    <circle id="Oval-4" cx="118.5" cy="112.5" r="84.5"></circle>
    <circle id="Oval-4-Copy" cx="269" cy="173" r="53"></circle>
    <circle id="Oval-4-Copy-5" cx="508" cy="94" r="53"></circle>
    <circle id="Oval-4-Copy-2" cx="371" cy="60" r="60"></circle>
    <circle id="Oval-4-Copy-6" cx="654" cy="137" r="60"></circle>
    <circle id="Oval-4-Copy-7" cx="704.5" cy="48.5" r="19.5"></circle>
    <circle id="Oval-4-Copy-17" cx="775" cy="38" r="9"></circle>
    <circle id="Oval-4-Copy-8" cx="537.5" cy="184.5" r="26.5"></circle>
    <circle id="Oval-4-Copy-9" cx="278" cy="84" r="16"></circle>
    <circle id="Oval-4-Copy-10" cx="216.5" cy="35.5" r="24.5"></circle>
    <circle id="Oval-4-Copy-11" cx="177.5" cy="225.5" r="19.5"></circle>
    <circle id="Oval-4-Copy-12" cx="12.5" cy="185.5" r="12.5"></circle>
    <circle id="Oval-4-Copy-13" cx="46.5" cy="28.5" r="12.5"></circle>
    <circle id="Oval-4-Copy-19" cx="542.5" cy="238.5" r="12.5"></circle>
    <circle id="Oval-4-Copy-14" cx="467.5" cy="165.5" r="12.5"></circle>
    <circle id="Oval-4-Copy-15" cx="787.5" cy="172.5" r="12.5"></circle>
    <circle id="Oval-4-Copy-16" cx="753" cy="113" r="22"></circle>
    <circle id="Oval-4-Copy-3" cx="370.5" cy="177.5" r="30.5"></circle>
    <circle id="Oval-4-Copy-18" cx="455" cy="247" r="41"></circle>
    <circle id="Oval-4-Copy-20" cx="357" cy="290" r="25"></circle>
    <circle id="Oval-4-Copy-21" cx="278" cy="253" r="8"></circle>
    <circle id="Oval-4-Copy-22" cx="476" cy="20" r="8"></circle>
    <circle id="Oval-4-Copy-23" cx="573" cy="138" r="8"></circle>
    <circle id="Oval-4-Copy-24" cx="233" cy="100" r="8"></circle>
    <circle id="Oval-4-Copy-25" cx="23" cy="63" r="5"></circle>
    <circle id="Oval-4-Copy-4" cx="601.5" cy="46.5" r="30.5"></circle>
</g>
