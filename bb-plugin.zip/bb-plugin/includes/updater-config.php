<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'    => 'Beaver Builder Plugin (Pro Version)',
		'version' => '2.5.4.3',
		'slug'    => 'bb-plugin',
		'type'    => 'plugin',
	));
}
