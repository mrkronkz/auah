<?php

namespace MaxButtons\ScssPhp\ScssPhp;

final class OutputStyle
{
    const EXPANDED = 'expanded';
    const COMPRESSED = 'compressed';
}
