<?php

namespace MaxButtons\ScssPhp\ScssPhp\Exception;

interface SassException
{
}
